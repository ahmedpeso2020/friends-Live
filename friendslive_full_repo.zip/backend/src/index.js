const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

let USERS = {};
let STREAMS = {};
let GIFTS = [
  { id: 'g1', name: 'Rose', price: 10 },
  { id: 'g2', name: 'Star', price: 50 },
  { id: 'g3', name: 'Rocket', price: 200 }
];
let WALLETS = {};

app.get('/api/v1/ping', (req,res)=>res.json({pong: true, ts: Date.now()}));

// Auth (very basic mock)
app.post('/api/v1/auth/register', (req,res)=>{
  const {username,email,password} = req.body;
  const id = uuidv4();
  USERS[id] = { id, username, email };
  WALLETS[id] = { balance: 1000, locked: 0 };
  res.json({ id, username });
});
app.post('/api/v1/auth/login', (req,res)=>{
  // mock login by username
  const { username } = req.body;
  const found = Object.values(USERS).find(u=>u.username===username);
  if(!found) return res.status(401).json({error:'not found'});
  res.json({ user: found, token: 'MOCK-TOKEN' });
});

// Streams
app.get('/api/v1/streams', (req,res)=>res.json(Object.values(STREAMS)));
app.post('/api/v1/streams', (req,res)=>{
  const { streamer_id, title } = req.body;
  const id = uuidv4();
  STREAMS[id] = { id, streamer_id, title, status:'offline', stream_key: uuidv4() };
  res.json(STREAMS[id]);
});
app.post('/api/v1/streams/:id/start', (req,res)=>{
  const s = STREAMS[req.params.id];
  if(!s) return res.status(404).send('not found');
  s.status='live'; s.started_at = Date.now();
  res.json(s);
});
app.post('/api/v1/streams/:id/stop', (req,res)=>{
  const s = STREAMS[req.params.id];
  if(!s) return res.status(404).send('not found');
  s.status='offline'; s.ended_at = Date.now();
  res.json(s);
});

// Gifts & wallet
app.get('/api/v1/gifts', (req,res)=>res.json(GIFTS));
app.get('/api/v1/wallet/:userId', (req,res)=>{
  const w = WALLETS[req.params.userId];
  if(!w) return res.status(404).json({error:'no wallet'});
  res.json(w);
});
app.post('/api/v1/gifts/send', (req,res)=>{
  const { from, to, giftId, streamId } = req.body;
  const gift = GIFTS.find(g=>g.id===giftId);
  if(!gift) return res.status(400).json({error:'gift not found'});
  if(!WALLETS[from] || WALLETS[from].balance < gift.price) return res.status(400).json({error:'insufficient'});
  WALLETS[from].balance -= gift.price;
  // credit to receiver
  if(!WALLETS[to]) WALLETS[to] = { balance:0, locked:0 };
  WALLETS[to].balance += Math.round(gift.price * 0.7); // 30% platform cut
  res.json({ success:true });
});

// Poker tables (basic)
let TABLES = {};
app.get('/api/v1/poker/tables', (req,res)=>res.json(Object.values(TABLES)));
app.post('/api/v1/poker/tables', (req,res)=>{
  const id = uuidv4();
  const { host_user_id, table_name, min_bet, max_players, buy_in } = req.body;
  TABLES[id] = { id, host_user_id, table_name, min_bet, max_players, buy_in, status:'waiting', players:[] };
  res.json(TABLES[id]);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Backend running on', PORT));
