import React from 'react';
import { Text, View, Image, TouchableOpacity } from 'react-native';

export default function App() {
  return (
    <View style={{flex:1, backgroundColor:'#FFF5F2', alignItems:'center', justifyContent:'center', padding:20}}>
      <Image source={require('./assets/icon.png')} style={{width:120,height:120, borderRadius:20}} />
      <Text style={{fontSize:22, fontWeight:'700', marginTop:16}}>Friends Live</Text>
      <Text style={{fontSize:14, color:'#444', marginTop:8, textAlign:'center'}}>تطبيق بث مباشر مع بوكر وميني-ألعاب. هذا إصدار عرضي لتجربة الواجهة.</Text>
      <TouchableOpacity style={{marginTop:20, backgroundColor:'#FF7A7A', paddingVertical:12, paddingHorizontal:24, borderRadius:12}}>
        <Text style={{color:'#fff'}}>ابدأ التجربة</Text>
      </TouchableOpacity>
    </View>
  );
}
