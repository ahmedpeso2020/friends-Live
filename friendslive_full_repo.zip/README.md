Friends Live - Full Repo Skeleton
This repository is an initial full-stack skeleton for Friends Live (MVP).
It includes:
- backend/ : Express mock backend with basic endpoints
- game-server/ : WebSocket lightweight game server skeleton
- mobile/ : Expo React Native basic app with placeholder assets
- infra/ : docker-compose and nginx.conf for quick local orchestration

Important notes:
- This is a development skeleton. You must secure, harden, and complete the implementations before production.
- For production streaming at scale, consider managed streaming/CDN, autoscaling, GPU transcoders, and professional ops.
- For iOS builds, use a Mac or cloud CI (EAS, Codemagic). For Android, run `expo build` or use EAS.

Quick start (local, requires Docker):
1. cd infra
2. docker-compose up --build
3. backend -> http://localhost:3000
4. game-server WebSocket ws://localhost:4000

Security & production checklist included in the previous conversation responses.
