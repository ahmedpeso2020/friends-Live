const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');

const wss = new WebSocket.Server({ port: 4000 });
console.log('Game server listening on 4000');

let tables = {}; // simple in-memory

wss.on('connection', (ws) => {
  ws.id = uuidv4();
  ws.on('message', (msg)=>{
    try{
      const data = JSON.parse(msg);
      if(data.type === 'create_table'){
        const id = uuidv4();
        tables[id] = { id, host: data.host, players: [data.host], status: 'waiting' };
        ws.send(JSON.stringify({ type:'table_created', table: tables[id] }));
      } else if(data.type === 'join_table'){
        const t = tables[data.tableId];
        if(!t) return ws.send(JSON.stringify({type:'error', message:'no table'}));
        t.players.push(data.user);
        // broadcast to all connected clients a simple event (naive)
        wss.clients.forEach(c=>{
          if(c.readyState === WebSocket.OPEN) c.send(JSON.stringify({type:'table_update', table: t}));
        });
      }
    }catch(e){
      console.error(e);
    }
  });
});
